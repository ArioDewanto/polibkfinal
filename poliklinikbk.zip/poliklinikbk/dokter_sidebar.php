<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link " href="index3.php?page=dashdokter">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
        <a class="nav-link " href="index3.php?page=jadwalperiksa">
          <i class="bi bi-person"></i>
          <span>Jadwal Periksa</span>
        </a>
        <a class="nav-link " href="index3.php?page=memeriksapasien">
          <i class="bi bi-person"></i>
          <span>Memeriksa Pasien</span>
        </a>
        <a class="nav-link " href="index3.php?page=riwayatpasien">
          <i class="bi bi-journal-text"></i>
          <span>Riwayat Pasien</span>
        </a>
    
        <a class="nav-link " href="index3.php?page=editprofil">
          <i class="bi bi-person"></i>
          <span>Profil</span>
        </a>
        </li><!-- End Dashboard Nav -->
    </ul>
</aside>