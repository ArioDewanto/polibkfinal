<?php 
$databaseHost = 'localhost';
$databaseName = 'polibk';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);