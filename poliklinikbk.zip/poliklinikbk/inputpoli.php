<?php

include 'conpoli.php';

if (!isset($_SESSION)) {
    session_start();
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>AdminSCK</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/stylebot.css" rel="stylesheet">
    <title>Admin POLI</title>   <!--Judul Halaman-->
</head>

<body>
            <main id="main" class="main" style="margin-top:50px">
                <section>
                <div class="pagetitle" style="margin-top:80px;">
                    <h1>Input Data Pasien</h1>
                        <nav>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php?page=dashboard">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                        </nav>
                        <form method="POST" action="" name="myForm" onsubmit="return(validate());">
            <!-- Kode php untuk menghubungkan form dengan database -->
            <?php
            $nama_poli = '';
            $keterangan = '';
            if (isset($_GET['id'])) {
                $ambil = mysqli_query($mysqli, "SELECT * FROM poli WHERE id='" . $_GET['id'] . "'");
                while ($row = mysqli_fetch_array($ambil)) {
                    $nama_poli = $row['nama_poli'];
                    $keterangan = $row['keterangan'];
                }
            ?>
                <input type="hidden" name="id" value="<?php echo
                $_GET['id'] ?>">
            <?php
            }
            ?>        
                </div><!-- End Page Title -->
                    <div class="row">
                        <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                            
                            <h5 class="card-title" style="text-align:center; padding:20px">Form Data Pasien</h5>
                            <!-- Table with stripped rows -->
                            <div class="col">
                                <label for="inputIsi" class="form-label fw-bold">
                                    Nama Poli
                                </label>
                                <input type="text" class="form-control" name="nama_poli" id="inputIsi" placeholder="Nama Poli" value="<?php echo $nama_poli ?>">
                            </div>
                            <div class="col mb-2">
                                <label for="inputTanggalAkhir" class="form-label fw-bold">
                                    Keterangan
                                </label>
                                <input type="text" class="form-control" name="keterangan" id="asal" placeholder="Masukkan Keterangan" value="<?php echo $keterangan?>">
                            
                            <div class="col" style="text-align:right; padding:20px">
                                <button type="submit" class="btn btn-primary rounded-pill px-3" name="simpan">Simpan</button>
                            </div>
                            </form>
                            </div>
                            </div>
                        </div>
                        </div>
                </section>
        </main>
        <?php
                if (isset($_POST['simpan'])) {
                    if (isset($_POST['id'])) {
                        $ubah = mysqli_query($mysqli, "UPDATE poli SET 
                                                        nama_poli = '" . $_POST['nama_poli'] . "',
                                                        keterangan = '" . $_POST['keterangan'] . "
                                                        WHERE
                                                        id = '" . $_POST['id'] . "'");
                    } else {
                        $tambah = mysqli_query($mysqli, "INSERT INTO poli(nama_poli,keterangan) 
                                                        VALUES ( 
                                                            '" . $_POST['nama_poli'] . "',
                                                            '" . $_POST['keterangan'] . "'
                                                            )");
                    }
                    echo '<script>alert("Data berhasil disimpan!");</script>';
                    echo "<script>document.location='index.php?page=inputpoli';</script>";
                }

                if (isset($_GET['aksi'])) {
                    if ($_GET['aksi'] == 'hapus') {
                        $hapus = mysqli_query($mysqli, "DELETE FROM poli WHERE id = '" . $_GET['id'] . "'");
                    }

                    echo "<script> 
                            document.location='index.php?page=inputpoli';
                            </script>";
                }
                ?>

    </div>
<script>
    function myFunction() {
        var x = document.getElementById("id_booking");
        x.value = x.value.toUpperCase();
    }
</script>
</body>
</html>