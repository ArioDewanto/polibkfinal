<?php

include 'conpoli.php';

if (!isset($_SESSION)) {
  session_start();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>AdminSCK</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <!-- Styles -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
<!-- Or for RTL support -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.rtl.min.css" />

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.full.min.js"></script>

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script> 
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/stylebot.css" rel="stylesheet">
    <title>Admin POLI</title>   <!--Judul Halaman-->
</head>

<body>
            <main id="main" class="main" style="margin-top:50px">
                <section>
                <div class="pagetitle" style="margin-top:80px;">
                    <h1>Input Data Periksa</h1>
                        <nav>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php?page=dashboard">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                        </nav>
            
                        
                        <form class="form-horizontal" method="POST" action="" name="myForm" onsubmit="return validateForm();">
                        <!-- PHP code to retrieve data if ID is set -->
                        <?php
                        $id_pasien = '';
                        $id_dokter = '';
                        $tgl_periksa = '';
                        $catatan = '';
                        $obat = [];
                        if (isset($_GET['id'])) {
                            $ambil = mysqli_query($mysqli, "SELECT * FROM periksa WHERE id='" . $_GET['id'] . "'");
                            while ($row = mysqli_fetch_array($ambil)) {
                                $id_pasien = $row['id_pasien'];
                                $id_dokter = $row['id_dokter'];
                                $tgl_periksa = $row['tgl_periksa'];
                                $catatan = $row['catatan'];
                                $detail_periksa = mysqli_query($mysqli, "SELECT * FROM detail_periksa WHERE id_periksa='" . $_GET['id'] . "'");
                                while ($row = mysqli_fetch_array($detail_periksa)) {
                                    $obat[] = $row['id_obat'];
                                }
                            }
                            ?>
                            <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
                            <?php
                            }
                            ?>
                </div><!-- End Page Title -->
                    <div class="row">
                        <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                            
                            <h5 class="card-title" style="text-align:center; padding:20px">Form Data Periksa</h5>
                            <!-- Table with stripped rows -->
                            <div class="col">
                            <label for="inputPasien" class="form-label fw-bold">Pasien</label>
                            <div>
                                <select class="form-control" name="id_pasien">
                                    <option hidden>Pilih Pasien</option>
                                    <?php
                                    $selected = '';
                                    $pasien = mysqli_query($mysqli, "SELECT * FROM pasien");
                                    while ($data = mysqli_fetch_array($pasien)) {
                                        if ($data['id'] == $id_pasien) {
                                            $selected = 'selected="selected"';
                                        } else {
                                            $selected = '';
                                        }
                                        ?>
                                        <option value="<?php echo $data['id'] ?>" <?php echo $selected ?>><?php echo $data['nama'] ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                            </div>
                            </div>
                            <div class="col mb-2">
                            <label for="inputDokter" class="form-label fw-bold">Dokter</label>
                            <div>
                                <select class="form-control" name="id_dokter">
                                    <option hidden>Pilih Dokter</option>
                                    <?php
                                    $selected = '';
                                    $dokter = mysqli_query($mysqli, "SELECT * FROM dokter");
                                    while ($data = mysqli_fetch_array($dokter)) {
                                        if ($data['id'] == $id_dokter) {
                                            $selected = 'selected="selected"';
                                        } else {
                                            $selected = '';
                                        }
                                        ?>
                                        <option value="<?php echo $data['id'] ?>" <?php echo $selected ?>><?php echo $data['nama'] ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                            </div>
                                <div class="col mb-2">
                                <label for="inputTanggal" class="form-label fw-bold">Tanggal Periksa</label>
                                <div>
                                    <input type="datetime-local" class="form-control" name="tgl_periksa" id="inputTanggal"
                                        placeholder="Tanggal Periksa" value="<?php echo $tgl_periksa ?>">
                                </div>
                            </div>
                            <div class="col mb-2">
                                <label for="inputCatatan" class="form-label fw-bold">Catatan</label>
                                <div>
                                    <input type="text" class="form-control" name="catatan" id="inputCatatan" placeholder="Catatan"
                                        value="<?php echo $catatan ?>">
                                </div>
                            </div>
                            <div class="col mb-2">
                                <label for="inputObat" class="form-label fw-bold">Obat</label>
                                <select class="form-select" id="multiple-select-field" name="obat[]" multiple="multiple">
                                    <?php
                                    $all_obat = mysqli_query($mysqli, "SELECT * FROM obat");

                                    while ($data = mysqli_fetch_array($all_obat)) {
                                        $selected = '';
                                        // Memeriksa apakah obat terpilih
                                        if (isset($obat) && is_array($obat)) {
                                            foreach ($obat as $obat_id) {
                                                $obat_terpilih = mysqli_fetch_array(mysqli_query($mysqli, "SELECT * FROM obat WHERE id='" . $obat_id . "'"));

                                                if ($obat_terpilih && $obat_terpilih['id'] == $data['id']) {
                                                    $selected = 'selected="selected"';
                                                    break;
                                                }
                                            }
                                        }

                                        // Menampilkan opsi obat dalam dropdown
                                        ?>
                                        <option value="<?php echo $data['id'] ?>" <?php echo $selected ?>><?php echo $data['nama_obat'] ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col" style="text-align:right; padding:20px">
                                <button type="submit" class="btn btn-primary rounded-pill px-3" name="simpan">Simpan</button>
                            </div>
                            </form>
                            </div>
                            </div>
                        </div>
                        </div>
                </section>
        </main>
        <?php
                if (isset($_POST['simpan'])) {
                    if (isset($_POST['id'])) {
                        $ubah = mysqli_query($mysqli, "UPDATE pasien SET 
                                                        nama = '" . $_POST['nama'] . "',
                                                        alamat = '" . $_POST['alamat'] . "',
                                                        no_ktp = '" . $_POST['no_ktp'] . "',
                                                        no_hpt = '" . $_POST['no_hp'] . "',
                                                        no_rm = '" . $_POST['no_rm'] . "'
                                                        WHERE
                                                        id = '" . $_POST['id'] . "'");
                    } else {
                        $tambah = mysqli_query($mysqli, "INSERT INTO pasien(nama,alamat,no_ktp,no_hp,no_rm) 
                                                        VALUES ( 
                                                            '" . $_POST['nama'] . "',
                                                            '" . $_POST['alamat'] . "',
                                                            '" . $_POST['no_ktp'] . "',
                                                            '" . $_POST['no_hp'] . "',
                                                            '" . $_POST['no_rm'] . "'
                                                            )");
                    }
                    echo '<script>alert("Data berhasil disimpan!");</script>';
                    echo "<script>document.location='index3.php?page=periksa';</script>";
                }

                if (isset($_GET['aksi'])) {
                    if ($_GET['aksi'] == 'hapus') {
                        $hapus = mysqli_query($mysqli, "DELETE FROM pasien WHERE id = '" . $_GET['id'] . "'");
                    }

                    echo "<script> 
                            document.location='index.php?page=dataperiksa';
                            </script>";
                }
                ?>

    </div>
    <script>
    $( '#multiple-select-field' ).select2( {
    theme: "bootstrap-5",
    width: $( this ).data( 'width' ) ? $( this ).data( 'width' ) : $( this ).hasClass( 'w-100' ) ? '100%' : 'style',
    placeholder: $( this ).data( 'placeholder' ),
    closeOnSelect: false,
} );
    </script>
</body>
</html>