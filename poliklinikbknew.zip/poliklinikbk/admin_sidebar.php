<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link " href="index2.php?page=dashboard">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
        <a class="nav-link " href="index2.php?page=datapasien">
          <i class="bi bi-person"></i>
          <span>Data Pasien</span>
        </a>
        <a class="nav-link " href="index2.php?page=datadokter">
          <i class="bi bi-person"></i>
          <span>Data Dokter</span>
        </a>
        <a class="nav-link " href="index2.php?page=dataobat">
          <i class="bi bi-person"></i>
          <span>Data Obat</span>
        </a>
        <a class="nav-link " href="index2.php?page=datapoli">
          <i class="bi bi-person"></i>
          <span>Data Poli</span>
        </a>
        </li><!-- End Dashboard Nav -->
    </ul>
</aside>