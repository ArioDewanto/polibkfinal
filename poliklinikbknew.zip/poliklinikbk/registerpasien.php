<?php

include 'conpoli.php';



if (!isset($_SESSION)) {
    session_start();
}

if (isset($_POST['submit'])) {
	$username = $_POST['nama'];
	$alamat = $_POST['alamat'];
	$no_hp = $_POST['no_hp'];
	$no_ktp = $_POST['alamat'];
	$password = md5($_POST['password']);
	$cpassword = md5($_POST['cpassword']);

	if ($password == $cpassword) {
		$yearMonth = date('Ym');

        // Get the current counter value for the given year and month
        $queryCounter = "SELECT MAX(SUBSTRING(no_rm, 8)) AS max_counter FROM pasien WHERE no_rm LIKE '$yearMonth%'";
        $resultCounter = $mysqli->query($queryCounter);

        if ($resultCounter === false) {
            die("Query error: " . $mysqli->error);
        }

        $counter = 1; // Default counter value if no records found
        if ($resultCounter->num_rows > 0) {
            $row = $resultCounter->fetch_assoc();
            $counter = (int)$row['max_counter'] + 1;
        }

        // Pad the counter with leading zeros (e.g., 001, 002, ...)
        $paddedCounter = str_pad($counter, 3, '0', STR_PAD_LEFT);

        // Combine the yearMonth and paddedCounter to form the final no_rm
        $no_rm = $yearMonth . '-' . $paddedCounter;
		$sql = "SELECT * FROM pasien WHERE nama='$username'";
		$result = mysqli_query($mysqli, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO pasien (nama, password, alamat, no_ktp, no_hp, no_rm) 
			VALUES ('$username', '$password', '$alamat', '$no_ktp', '$no_hp', '$no_rm')";
			$result = mysqli_query($mysqli, $sql);
			if ($result) {
				echo "<script>alert('Pendaftaran Berhasil'); 
				document.location='loginpasien.php';</script>";
				$username = "";
				$email = "";
				$_POST['password'] = "";
				$_POST['cpassword'] = "";
			} else {
				echo "<script>alert('Woops! Something Wrong Went.')</script>";
			}
		} else {
			echo "<script>alert('Woops! Username Already Exists.')</script>";
		}

	} else {
		echo "<script>alert('Password Not Matched.')</script>";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Register Form </title>
</head>
<body  style="background-image: 2.jpg;">
	<div class="container">
		<form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Register</p>
			<div class="input-group">
				<input type="text" placeholder="nama" name="nama" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Alamat" name="alamat" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Nomor HP" name="no_hp" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Nomor KTP" name="no_ktp" required>
			</div>
			<div class="input-group">
				<input type="password" placeholder="Password" name="password" required>
            </div>
            <div class="input-group">
				<input type="password" placeholder="Confirm Password" name="cpassword" required>
			</div>
			<div class="input-group">
				<button name="submit" class="btn">Register</button>
			</div>
			<p class="login-register-text">Have an account? <a href="loginpasien.php">Login Here</a>.</p>
		</form>
	</div>
</body>
</html>
