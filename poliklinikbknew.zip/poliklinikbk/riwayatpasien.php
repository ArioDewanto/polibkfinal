<?php
if (!isset($_SESSION)) {
  session_start();
}

// Fetch data from the 'pasien' table
$pasienQuery = "SELECT * FROM pasien";
$pasienResult = $mysqli->query($pasienQuery);

// Fetch the data as an associative array
$pasienData = $pasienResult->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DokterPoli</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/stylebot.css" rel="stylesheet">
</head>

<body>
  
<main id="main" class="main" style="margin-top:50px">
                <section class="section">
                <div class="pagetitle" style="margin-top:80px">
                    <h1>Riwayat Periksa Pasien</h1>
                        <nav>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php?page=dashboard">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                </div><!-- End Page Title -->
                    <div class="row" style="text-align:center;">
                        <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                            <h5 class="card-title" style="text-align:center; padding:20px" >Riwayat Periksa Pasien</h5>
                            <!-- Table with stripped rows -->

<!-- Table -->
<table class="table table-hover">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Nama Pasien</th>
        <th scope="col">Nama Dokter</th>
        <th scope="col">Tanggal Periksa</th>
        <th scope="col">Catatan</th>
        <th scope="col">Obat</th>
        <th scope="col">Aksi</th>
    </tr>
    </thead>
    <tbody>
    <!-- PHP code to fetch and display data -->
    <?php
    $result = mysqli_query($mysqli,
        "SELECT 
                    pr.*,
                    d.nama AS 'nama_dokter', 
                    p.nama AS 'nama_pasien', 
                    GROUP_CONCAT(o.nama_obat SEPARATOR ', ') AS 'obat'
                FROM periksa pr 
                LEFT JOIN dokter d ON (pr.id_dokter = d.id) 
                LEFT JOIN pasien p ON (pr.id_pasien = p.id)
                LEFT JOIN detail_periksa dp ON (pr.id = dp.id_periksa)
                LEFT JOIN obat o ON (dp.id_obat = o.id)
                GROUP BY pr.id
                ORDER BY pr.tgl_periksa DESC");
    $no = 1;
    while ($data = mysqli_fetch_array($result)) {
        ?>
        <tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $data['nama_pasien'] ?></td>
            <td><?php echo $data['nama_dokter'] ?></td>
            <td><?php echo $data['tgl_periksa'] ?></td>
            <td><?php echo $data['catatan'] ?></td>
            <td style="width: 25%"><?php echo $data['obat'] == null ? 'Tidak ada obat' : $data['obat']; ?></td>
            <td>
                <a class="btn btn-success rounded-pill px-3" href="index3.php?page=periksa&id=<?php echo $data['id'] ?>">Ubah</a>
                <a class="btn btn-danger rounded-pill px-3"href="index3.php?page=periksa&id=<?php echo $data['id'] ?>&aksi=hapus">Hapus</a>
                <a target="_blank" class="btn btn-warning rounded-pill px-3" href="index3.php?page=invoice&id=<?= $data['id'] ?>">Nota</a>
            </td>
        </tr>
        <?php
    }
    ?>
    </tbody>
</table>
<?php
    if (isset($_POST['simpan'])) {
        if (isset($_POST['id'])) {
            $ubah = mysqli_query($mysqli, "UPDATE periksa SET 
                                                id_pasien = '" . $_POST['id_pasien'] . "',
                                                id_dokter = '" . $_POST['id_dokter'] . "',
                                                tgl_periksa = '" . $_POST['tgl_periksa'] . "',
                                                catatan = '" . $_POST['catatan'] . "'
                                                WHERE id = '" . $_POST['id'] . "'");
            $hapus_detail = mysqli_query($mysqli, "DELETE FROM detail_periksa WHERE id_periksa = '" . $_POST['id'] . "'");
            foreach ($_POST['obat'] as $obat) {
                $tambah_detail = mysqli_query($mysqli, "INSERT INTO detail_periksa (id_periksa, id_obat) 
                                                VALUES (
                                                    '" . $_POST['id'] . "',
                                                    '" . $obat . "'
                                                )");
            }
        } else {
            $tambah = mysqli_query($mysqli, "INSERT INTO periksa (id_pasien, id_dokter, tgl_periksa, catatan) 
                                                VALUES (
                                                    '" . $_POST['id_pasien'] . "',
                                                    '" . $_POST['id_dokter'] . "',
                                                    '" . $_POST['tgl_periksa'] . "',
                                                    '" . $_POST['catatan'] . "'
                                                )");
            $periksa_id = mysqli_insert_id($mysqli);
            foreach ($_POST['obat'] as $obat) {
                $tambah_detail = mysqli_query($mysqli, "INSERT INTO detail_periksa (id_periksa, id_obat) 
                                                VALUES (
                                                    '" . $periksa_id . "',
                                                    '" . $obat . "'
                                                )");
            }
        }
        echo "<script> 
                    document.location='index3.php?page=periksa';
                    </script>";
    }

    if (isset($_GET['aksi'])) {
        if ($_GET['aksi'] == 'hapus') {
            $hapus = mysqli_query($mysqli, "DELETE FROM periksa WHERE id = '" . $_GET['id'] . "'");
        }

        echo "<script> 
                    document.location='index3.php?page=periksa';
                    </script>";
    }
?>
</div>
<script>
    $(document).ready(function () {
        $('.js-example-basic-multiple').select2();
    });
</script>
</body>

</html>
